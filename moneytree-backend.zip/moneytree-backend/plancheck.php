<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
include('include/User.php');
$user = new User();
$lst= [];

$userid = $_GET['userid'];
for($n=1;$n<=4;$n++){  
$sql1 = "SELECT `id`, `user_id`, `plan_id`, `type`, `status`, SUM(`amount`)as 'purchase', `create_date` FROM `plan_user` WHERE `plan_id`=$n and `user_id`=".$userid." and  `type` = 'purchase'";
$result1 = mysqli_query($user->dbConnect,$sql1);
$re1 =mysqli_fetch_assoc($result1);
$purchase = $re1['purchase'];

$sql2 = "SELECT `id`, `user_id`, `plan_id`, `type`, `status`, SUM(`amount`)as 'sell', `create_date` FROM `plan_user` WHERE `plan_id`=$n and `user_id`=".$userid." and  `type` = 'sell'";
$result2 = mysqli_query($user->dbConnect,$sql2);
$re2=mysqli_fetch_assoc($result2);
$sell = $re2['sell'];
$currentamount= $purchase -$sell;
$lst[$n] = $currentamount;
}
echo json_encode($lst);
?>